# Muestreo de Calidad — Android offline

Proyecto Android con una calculadora de muestreo integrada como contenido local. No necesita internet para funcionar una vez instalada.

## Generar el APK desde un celular
1. Crea un repositorio nuevo en GitHub desde el navegador del teléfono.
2. Sube **el contenido de esta carpeta** al repositorio (la carpeta `.github` también debe subirse).
3. En GitHub abre la pestaña **Actions**.
4. En el flujo **Construir APK**, pulsa **Run workflow**.
5. Espera a que termine correctamente.
6. Abre la ejecución terminada y busca **Artifacts**.
7. Descarga `MuestreoCalidad-debug-apk.zip`, extráelo y tendrás `app-debug.apk`.
8. Abre el APK en Android y permite la instalación desde esa fuente si el teléfono lo solicita.

El APK de debug es para pruebas. Antes de usarlo como herramienta oficial de Calidad conviene validar las tablas ANSI/ASQ Z1.4 y después generar una versión firmada de producción.
